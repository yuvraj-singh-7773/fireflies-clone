# Fireflies Clone Sample Data

This package contains a copy of the supplied SQLite database with additional sample meeting data added.
The existing database schema and existing records were preserved; only sample rows were added.

Added:
- 4 past meetings
- participants
- full transcript segments
- persisted summaries and key topics
- action items with completed/incomplete states
- chapters
- tags
- 4 lightweight WAV demo audio files

Audio paths stored in the database:
- /audio/meeting-product-roadmap-planning.wav
- /audio/meeting-engineering-sprint-review.wav
- /audio/meeting-customer-feedback-session.wav
- /audio/meeting-design-system-sync.wav

Important:
Copy the WAV files into your Next.js `frontend/public/audio/` directory so `/audio/...` URLs resolve in the player.
Use `firefiles_filled.db` as the SQLite database only after backing up your current database.

The seeded meetings belong to the first existing user in the supplied database, so they should appear for that account under the application's ownership rules.
